CCNP ENARSI
Curso: Seguridad de la infraestructura
Ejercicio: Troubleshooting ACL IPv4
Firmware: Routers  -> c7200-advipservicesk9-mz.152-4.S5.bin
Autor: José Tomás López